
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime;
import sys
import utils
tsFormat='%Y-%m-%d_%H:%M:%S'
reload(sys)

connector = utils.getDBConnection()
driver=utils.getDriver()


def task0_1():
	# Fetch the page
	URL='https://www.cl.cam.ac.uk/people/'
	utils.fetchPage(driver,URL)

	# Scrape the left-hand menu for member categories
	memberCategories=driver.find_elements_by_xpath('//ul[@id="nav-primary"]/li')
	print "There are %s member categories"%len(memberCategories)

	#Loop through categories and print their text and url
	for cat in memberCategories:
		url=cat.find_element_by_tag_name('a').get_attribute('href')
		print "\t%s - %s"%(cat.text,url)

def task0_2():
	# Set the query
	query=('PRAGMA table_info("Users")')

	# Get a cursor and execute the query
	cursor=connector.cursor()
	cursor.execute(query)

	# Get all the rows returned by the query and print
	rows=cursor.fetchall()
	print 'Columns OF TABLE "Users"'
	print '(Name - Type)'
	print '----------------'
	for row in rows:
		print "%s - %s"%(row[1],row[2])

		# Set the query
	query=('SELECT * FROM "Users"')

	# Get a cursor and execute the query
	cursor=connector.cursor()
	cursor.execute(query)

	# Get all the rows returned by the query and print
	rows=cursor.fetchall()
	print "Currently there are %s users in the database"%len(rows)

# WRITE YOUR TASKS HERE




task0_2()
utils.quitDriver(driver)
